# 🚀 Laravel God Mode - Multi-Application Laravel Management

A modern, Forge-like control panel for managing unlimited Laravel applications with Docker. Simple, powerful, and beautiful.

![Laravel God Mode Dashboard](docs/images/dashboard.png)

## ✨ Features

### 🎛️ **Forge-like Web Interface**
- Beautiful, modern dark theme UI
- Real-time application status monitoring
- One-click create, start, stop, delete operations
- Live log streaming with WebSocket connectivity
- Environment variable editor with syntax highlighting
- Built-in terminal for direct command execution

### 🚀 **Smart Application Management**
- Create unlimited Laravel applications instantly
- Auto-assign ports with conflict detection
- Template-based setup (Laravel 8, 9, 10, 11)
- PHP version switching (8.1, 8.2, 8.3, 8.4)
- Node.js version switching (16, 18, 20)
- Service management (MySQL, Redis, Mailhog, etc.)

### 🔧 **Complete Development Stack**
- **Laravel**: Latest versions with Artisan support
- **MySQL 8.0**: Dedicated database per application
- **Redis**: Caching, sessions, and queue management
- **PHPMyAdmin**: Database administration interface
- **Mailhog**: Email testing and debugging
- **Redis Insight**: Redis management dashboard
- **Nginx**: High-performance web server
- **Supervisor**: Process management and monitoring

### ⚡ **Developer Experience**
- One command setup: `make install`
- Powerful Makefile with intuitive commands
- Real-time command execution with output streaming
- Live log viewing with filtering capabilities
- Environment management with validation
- Automatic backup and restore functionality
- Health monitoring and alerting

## 🚀 Quick Start

```bash
# Clone the repository
git clone https://github.com/your-username/laradocker-pro.git
cd laradocker-pro

# One-command setup
make install

# Start the control panel
make start

# Open your browser
open http://localhost:9000
```

That's it! 🎉 Your Laravel God Mode control panel is now running.

## 📋 Prerequisites

Before getting started, ensure you have the following installed:

- **Docker & Docker Compose**: Latest versions recommended
  ```bash
  # Install Docker (Ubuntu/Debian)
  curl -fsSL https://get.docker.com -o get-docker.sh
  sh get-docker.sh

  # Install Docker Compose
  sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
  sudo chmod +x /usr/local/bin/docker-compose
  ```

- **Node.js 18+**: For the control panel
  ```bash
  # Install Node.js (using NodeSource)
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
  ```

- **Git**: For Laravel project creation
  ```bash
  # Usually pre-installed, but if needed:
  sudo apt-get install git
  ```

- **Make**: For command execution (usually pre-installed on Linux/macOS)

## 🎯 Core Capabilities

### Application Management
- ✅ Create new Laravel applications with custom configurations
- ✅ Switch PHP versions per application (8.1, 8.2, 8.3, 8.4)
- ✅ Switch Node.js versions per application (16, 18, 20)
- ✅ Enable/disable services (Redis, MySQL, Mailhog, etc.)
- ✅ Environment variable management with validation
- ✅ Real-time monitoring with health checks
- ✅ One-click deployment and scaling

### Service Management
- ✅ MySQL 8.0 with dedicated databases per application
- ✅ Redis for caching, sessions, and queue management
- ✅ PHPMyAdmin for intuitive database management
- ✅ Mailhog for email testing and debugging
- ✅ Redis Insight for Redis monitoring and management
- ✅ Nginx with SSL support and performance optimization
- ✅ Supervisor for robust process management

### Developer Tools
- ✅ Artisan command execution with real-time output
- ✅ Composer management and dependency updates
- ✅ NPM/Yarn support for frontend assets
- ✅ Real-time log viewing with filtering and search
- ✅ SSH access to containers for debugging
- ✅ Database backups with scheduled automation
- ✅ File management with upload/download capabilities

## 📖 Detailed Usage

### Creating Your First Application

1. **Access the Control Panel**
   - Open http://localhost:9000 in your browser
   - You'll see the beautiful dark-themed dashboard

2. **Create a New Application**
   - Click the "Create Application" button
   - Fill in the application details:
     - **Name**: my-awesome-app (lowercase, hyphens allowed)
     - **Laravel Version**: Choose from 8, 9, 10, or 11
     - **PHP Version**: Select 8.1, 8.2, 8.3, or 8.4
     - **Node.js Version**: Choose 16, 18, or 20
     - **Services**: Select MySQL, Redis, Mailhog, etc.

3. **Application Creation Process**
   - The system will automatically:
     - Create a new Laravel project
     - Configure Docker containers
     - Set up the database
     - Configure environment variables
     - Start all services

4. **Access Your Application**
   - Once created, your app will be available at `http://localhost:PORT`
   - The port is automatically assigned and displayed in the dashboard

### Managing Applications

#### Starting/Stopping Applications
```bash
# Using the web interface (recommended)
# Click the Start/Stop buttons in the dashboard

# Using Make commands
make start-all    # Start all applications
make stop-all     # Stop all applications
```

#### Viewing Logs
- Click on an application card
- Navigate to the "Logs" tab
- View real-time logs with automatic scrolling
- Use the search and filter functionality

#### Running Commands
- Go to the "Terminal" tab in the application details
- Run any command directly in the container:
  ```bash
  php artisan migrate
  php artisan make:controller UserController
  composer require package/name
  npm install
  npm run dev
  ```

#### Environment Management
- Navigate to the "Environment" tab
- Edit variables directly in the built-in editor
- Validation ensures proper format
- Save and restart automatically applies changes

### Advanced Configuration

#### Custom PHP Extensions
Edit the Dockerfile template in `templates/Dockerfile`:
```dockerfile
# Add custom PHP extensions
RUN pecl install extension-name && docker-php-ext-enable extension-name
```

#### Custom Nginx Configuration
Modify `templates/nginx.conf` for application-specific settings:
```nginx
# Add custom locations
location /api/ {
    # Custom API configuration
}
```

#### Database Configuration
Each application gets its own MySQL database:
- Database name: same as application name
- Username: root / application name
- Password: configurable in environment
- Access via PHPMyAdmin at `http://localhost:8080`

## 🛠️ Command Reference

### Setup Commands
```bash
make install      # Complete setup (recommended for first-time)
make setup        # Create directory structure only
make check        # Verify system requirements
```

### Control Panel Management
```bash
make start        # Start the control panel
make stop         # Stop the control panel
make restart      # Restart the control panel
make status       # Show current status
make logs         # View control panel logs
make dev          # Start in development mode
```

### Application Operations
```bash
make apps         # List all applications
make start-all    # Start all applications
make stop-all     # Stop all applications
```

### Maintenance
```bash
make clean        # Clean up containers and images
make prune        # Remove unused Docker resources
make backup       # Create backup of all applications
make update       # Update dependencies
make info         # Show system information
```

## 🏗️ Architecture

### Directory Structure
```
laradocker-pro/
├── control-panel/              # Node.js control panel
│   ├── server.js              # Main server application
│   ├── public/                # Web interface files
│   ├── config/                # Configuration files
│   └── templates/             # Application templates
├── applications/              # Individual Laravel apps
│   ├── my-app-1/             # Application directory
│   │   ├── src/              # Laravel source code
│   │   ├── docker-compose.yml
│   │   ├── Dockerfile
│   │   └── nginx.conf
│   └── my-app-2/
├── templates/                 # Docker templates
│   ├── docker-compose.yml    # Base template
│   ├── Dockerfile            # Base Dockerfile
│   ├── nginx.conf            # Nginx configuration
│   ├── php.ini              # PHP configuration
│   └── supervisord.conf      # Process management
├── docker-compose.yml        # Control panel services
├── Makefile                  # Command shortcuts
└── .env                      # Environment configuration
```

### Technology Stack
- **Backend**: Node.js + Express + Socket.io
- **Frontend**: Vanilla JavaScript + Modern CSS
- **Container**: Docker + Docker Compose
- **Database**: MySQL 8.0
- **Cache**: Redis 7
- **Web Server**: Nginx
- **Process Manager**: Supervisor
- **Email Testing**: Mailhog

### Security Features
- Container isolation for each application
- No privileged containers
- Environment variable encryption
- Rate limiting on API endpoints
- CORS protection
- SQL injection prevention
- XSS protection headers

## 🔧 Configuration

### Environment Variables
Copy `.env.example` to `.env` and customize:

```bash
# Control Panel
CONTROL_PANEL_PORT=9000
NODE_ENV=production

# Database
DB_PASSWORD=your-secure-password

# Default Versions
DEFAULT_PHP_VERSION=8.3
DEFAULT_NODE_VERSION=20
DEFAULT_LARAVEL_VERSION=11

# Port Ranges
APP_PORT_START=8000
APP_PORT_END=8999
```

### Custom Templates
Create custom application templates in `control-panel/templates/`:

```yaml
# custom-template.yml
version: '3.8'
services:
  app:
    # Your custom configuration
```

### SSL Configuration
Enable SSL for applications:

```bash
# In .env
SSL_ENABLED=true
SSL_CERT_PATH=/path/to/certs
SSL_KEY_PATH=/path/to/keys
```

## 📊 Monitoring & Logging

### Built-in Monitoring
- Real-time application status
- Resource usage tracking
- Health check endpoints
- Performance metrics

### Log Management
- Centralized logging for all applications
- Log rotation and retention
- Real-time log streaming
- Search and filtering capabilities

### Backup Strategy
- Automated daily backups
- Application data and configuration
- Database dumps included
- Configurable retention policies

## 🚨 Troubleshooting

### Common Issues

#### Port Already in Use
```bash
# Check what's using the port
sudo lsof -i :9000

# Kill the process
sudo kill -9 PID
```

#### Docker Permission Issues
```bash
# Add user to docker group
sudo usermod -aG docker $USER
# Logout and login again
```

#### Application Won't Start
```bash
# Check application logs
make logs

# Check Docker status
docker ps -a

# Restart the application
make restart
```

#### Database Connection Issues
```bash
# Verify MySQL is running
docker ps | grep mysql

# Check database logs
docker logs laradocker_mysql

# Reset database
make clean && make start
```

### Getting Help
- Check the logs: `make logs`
- Verify system requirements: `make check`
- View system information: `make info`
- Join our [Discord community](https://discord.gg/laradocker)
- Open an issue on [GitHub](https://github.com/your-username/laradocker-pro/issues)

## 🤝 Contributing

We welcome contributions! Here's how to get started:

1. **Fork the Repository**
   ```bash
   git clone https://github.com/your-username/laradocker-pro.git
   cd laradocker-pro
   ```

2. **Create a Branch**
   ```bash
   git checkout -b feature/amazing-feature
   ```

3. **Make Changes**
   - Follow the existing code style
   - Add tests for new features
   - Update documentation

4. **Test Your Changes**
   ```bash
   make clean
   make install
   make test
   ```

5. **Submit a Pull Request**
   - Describe your changes clearly
   - Link any related issues
   - Wait for review

### Development Setup
```bash
# Clone and setup for development
git clone https://github.com/your-username/laradocker-pro.git
cd laradocker-pro
make install
make dev  # Start in development mode
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙋‍♂️ Support

- **Documentation**: [Wiki](https://github.com/your-username/laradocker-pro/wiki)
- **Issues**: [GitHub Issues](https://github.com/your-username/laradocker-pro/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-username/laradocker-pro/discussions)
- **Email**: support@laradocker.pro
- **Discord**: [Join our community](https://discord.gg/laradocker)

## 🚀 Roadmap

- [ ] **v1.1**: Custom domain support with automatic SSL
- [ ] **v1.2**: Git integration for automatic deployments
- [ ] **v1.3**: Kubernetes support for production deployments
- [ ] **v1.4**: Plugin system for custom integrations
- [ ] **v1.5**: Team collaboration features
- [ ] **v2.0**: Cloud deployment support (AWS, DigitalOcean, etc.)

## 💖 Acknowledgments

- Thanks to the Laravel community for inspiration
- Docker team for making containerization accessible
- All contributors who help make this project better
- The open-source community for continuous inspiration

---

**Made with ❤️ for the Laravel community**

*Laravel God Mode - Because managing Laravel applications should be divine!* ⚡
